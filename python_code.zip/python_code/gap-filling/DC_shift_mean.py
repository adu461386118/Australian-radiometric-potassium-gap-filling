#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Feathered mosaic with DC-free blending (distance weights) and -99999 NoData.

- A is aligned to B's exact grid (CRS, transform, size) using a WarpedVRT.
- Mosaic rules:
  * only A valid     -> A
  * only B valid     -> B
  * both valid       -> (A*wA + B*wB) / (wA + wB), where w = distance to dataset edge
  * neither valid    -> NoData (-99999)
- Tiled processing with HALO so distance_transform_edt sees edges properly.

Requirements: rasterio, numpy, scipy (distance_transform_edt)
"""

from pathlib import Path
import sys
import numpy as np
import rasterio as rio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from rasterio.windows import Window
from scipy.ndimage import distance_transform_edt

# --------------------------- CONFIG -----------------------------------------


TIF_A   = "predictions_tas_K_combined_clip_v2.tif"
TIF_B   = "k_shift_scaled_proj_clip.tif"
OUT_TIF = "Projected_K_step3.tif"

#TIF_A   = "predictions_small_K_combined_clip.tif"
#TIF_B   = "Projected_K_step1.tif"
#OUT_TIF = "Projected_K_step2.tif"


#TIF_A   = "predictions_big_K_combined_clip.tif"
#TIF_B   = "Projected_K.tif"
#OUT_TIF = "Projected_K_step1.tif"

COMPRESS = "LZW"
TILE = 1024     # core tile size (pixels)
HALO = 128      # padding around each tile for correct distance-to-edge
EPS = 1e-6      # avoid division by zero
# ----------------------------------------------------------------------------

def expand_window(win: Window, halo: int, width: int, height: int) -> Window:
    """Return a new window expanded by 'halo' pixels on each side, clipped to bounds."""
    row_off = max(0, int(win.row_off) - halo)
    col_off = max(0, int(win.col_off) - halo)
    row_end = min(height, int(win.row_off + win.height) + halo)
    col_end = min(width,  int(win.col_off + win.width)  + halo)
    return Window(col_off, row_off, col_end - col_off, row_end - row_off)

def core_slices(big: Window, core: Window):
    """Return numpy slices that crop big arrays down to the core window."""
    top_pad  = int(core.row_off - big.row_off)
    left_pad = int(core.col_off - big.col_off)
    h, w = int(core.height), int(core.width)
    return (slice(top_pad, top_pad + h), slice(left_pad, left_pad + w))

def valid_mask(arr: np.ndarray, nodata: float) -> np.ndarray:
    """True for valid pixels (not nodata, finite)."""
    m = np.isfinite(arr)
    if nodata is not None:
        m &= (arr != nodata)
    return m

def feather_blend(a: np.ndarray, b: np.ndarray, a_valid: np.ndarray, b_valid: np.ndarray) -> np.ndarray:
    """
    Distance-weighted blend where both are valid. Weight = distance to each dataset's edge.
    For non-overlap, caller should have already selected A-only or B-only.
    """
    # Distances: distance_transform_edt computes distance from True to nearest False.
    # Give slightly eroded masks to ensure well-defined edges even when a tile is fully valid.
    # However, with HALO >= few pixels, this is typically robust.
    dA = distance_transform_edt(a_valid)
    dB = distance_transform_edt(b_valid)

    both = a_valid & b_valid
    out = np.empty_like(a, dtype=np.float32)

    # Fallback where both valid but both distances are zero (rare): use simple average
    denom = (dA + dB)
    zero_denom = both & (denom <= EPS)

    # Weighted blend
    wsum = np.maximum(denom, EPS).astype(np.float32)
    mix = (a.astype(np.float32) * dA.astype(np.float32) +
           b.astype(np.float32) * dB.astype(np.float32)) / wsum
    out[both] = mix[both]

    if np.any(zero_denom):
        out[zero_denom] = 0.5 * (a[zero_denom] + b[zero_denom]).astype(np.float32)

    return out

def main():
    a_path, b_path, out_path = Path(TIF_A), Path(TIF_B), Path(OUT_TIF)
    if not a_path.exists() or not b_path.exists():
        sys.exit("Input file(s) not found.")

    with rio.open(b_path) as B:
        # Output profile based on B
        prof = B.profile.copy()
        prof.update({
            "compress": COMPRESS,
            "tiled": True,
            "BIGTIFF": "YES",
            "driver": "GTiff",
            "nodata": -99999,
            "dtype": "float32",  # safe common dtype for blending
        })

        # Build a VRT for A that matches B's grid exactly
        with rio.open(a_path) as A_src:
            vrt_opts = {
                "crs": B.crs,
                "transform": B.transform,
                "width": B.width,
                "height": B.height,
                "resampling": Resampling.bilinear
            }
            with WarpedVRT(A_src, **vrt_opts) as A:

                if A.count != B.count:
                    raise ValueError(f"Band count mismatch: A={A.count}, B={B.count}")

                with rio.open(out_path, "w", **prof) as OUT:
                    # Process in core tiles over B grid
                    n_rows = B.height
                    n_cols = B.width
                    for row_off in range(0, n_rows, TILE):
                        for col_off in range(0, n_cols, TILE):
                            core = Window(col_off, row_off,
                                          min(TILE, n_cols - col_off),
                                          min(TILE, n_rows - row_off))
                            big = expand_window(core, HALO, n_cols, n_rows)
                            sl_big = (slice(int(big.row_off), int(big.row_off + big.height)),
                                      slice(int(big.col_off), int(big.col_off + big.width)))
                            sl_core = core_slices(big, core)

                            for band in range(1, B.count + 1):
                                # Read expanded windows from both datasets
                                a_big = A.read(band, window=big).astype(np.float32)
                                b_big = B.read(band, window=big).astype(np.float32)

                                a_nd = A.nodata if A.nodata is not None else -99999
                                b_nd = B.nodata if B.nodata is not None else -99999

                                a_val_big = valid_mask(a_big, a_nd)
                                b_val_big = valid_mask(b_big, b_nd)

                                # Start with NoData everywhere
                                out_big = np.full_like(a_big, fill_value=-99999, dtype=np.float32)

                                # Only A valid
                                onlyA = a_val_big & (~b_val_big)
                                if np.any(onlyA):
                                    out_big[onlyA] = a_big[onlyA]

                                # Only B valid
                                onlyB = b_val_big & (~a_val_big)
                                if np.any(onlyB):
                                    out_big[onlyB] = b_big[onlyB]

                                # Both valid -> feathered blend
                                both = a_val_big & b_val_big
                                if np.any(both):
                                    blended = feather_blend(a_big, b_big, a_val_big, b_val_big)
                                    out_big[both] = blended[both]

                                # Crop back to core and write
                                OUT.write(out_big[sl_core], band, window=core)

    print(f"Feathered mosaic written ? {out_path}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        sys.stderr.write(f"[ERROR] {e}\n")
        sys.exit(2)
