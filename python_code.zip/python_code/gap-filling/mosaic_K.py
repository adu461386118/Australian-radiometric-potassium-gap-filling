import numpy as np
import rasterio
from rasterio.warp import reproject, Resampling


SENTINEL_NODATA = -99999.0  # you said -99999 / -99999.0000 / -99999


def is_invalid(arr, nodata_value):
    """
    Invalid if:
      - masked (if masked array)
      - equals dataset nodata (if nodata is not None)
      - equals SENTINEL_NODATA (-99999)
      - NaN
    """
    invalid = np.zeros(arr.shape, dtype=bool)

    # If masked array, respect mask
    if np.ma.isMaskedArray(arr):
        invalid |= np.ma.getmaskarray(arr)
        arr_data = arr.data
    else:
        arr_data = arr

    invalid |= np.isnan(arr_data)

    if nodata_value is not None:
        invalid |= (arr_data == nodata_value)

    invalid |= (arr_data == SENTINEL_NODATA)
    return invalid


def reproject_to_match(ref_ds, src_path, out_dtype="float32", resampling=Resampling.nearest):
    """
    Reproject src raster to match ref_ds grid (shape/transform/crs).
    Returns (src_on_ref_grid, src_nodata).
    """
    with rasterio.open(src_path) as src:
        src_nodata = src.nodata

        dst = np.full(
            (ref_ds.height, ref_ds.width),
            SENTINEL_NODATA,
            dtype=out_dtype,
        )

        reproject(
            source=rasterio.band(src, 1),
            destination=dst,
            src_transform=src.transform,
            src_crs=src.crs,
            src_nodata=src_nodata,
            dst_transform=ref_ds.transform,
            dst_crs=ref_ds.crs,
            dst_nodata=SENTINEL_NODATA,
            resampling=resampling,
        )

    return dst, src_nodata


def main(a_path, b_path, c_path, d_path, out_path):
    # -------------------------
    # Step 0: read A (reference)
    # -------------------------
    with rasterio.open(a_path) as a_ds:
        a_profile = a_ds.profile.copy()
        a_nodata = a_ds.nodata

        # Read as masked so internal mask + nodata is preserved (if present)
        a = a_ds.read(1, masked=True).astype("float32")

        a_invalid = is_invalid(a, a_nodata)

        # -------------------------
        # Step 1: deal with B
        # If B is valid and A is invalid -> A = B
        # -------------------------
        b_on_a, b_nodata = reproject_to_match(a_ds, b_path, out_dtype="float32")
        b_invalid = is_invalid(b_on_a, b_nodata)

        replace_mask = (~b_invalid) & (a_invalid)
        a_data = a.data if np.ma.isMaskedArray(a) else a
        a_data[replace_mask] = b_on_a[replace_mask]
        a_invalid[replace_mask] = False  # those pixels are now valid

        # -------------------------
        # Step 2: deal with C
        # If C is valid -> A = C  (overwrite)
        # -------------------------
        c_on_a, c_nodata = reproject_to_match(a_ds, c_path, out_dtype="float32")
        c_invalid = is_invalid(c_on_a, c_nodata)

        overwrite_mask = (~c_invalid)
        a_data[overwrite_mask] = c_on_a[overwrite_mask]
        a_invalid[overwrite_mask] = False

        # -------------------------
        # Step 3: deal with D
        # If D is valid -> A = D  (overwrite)
        # -------------------------
        d_on_a, d_nodata = reproject_to_match(a_ds, d_path, out_dtype="float32")
        d_invalid = is_invalid(d_on_a, d_nodata)

        overwrite_mask = (~d_invalid)
        a_data[overwrite_mask] = d_on_a[overwrite_mask]
        a_invalid[overwrite_mask] = False

        # -------------------------
        # Step 4: write output
        # -------------------------
        out = a_data.astype("float32")
        # set remaining invalid pixels to nodata
        out_nodata = a_nodata if a_nodata is not None else SENTINEL_NODATA
        out[a_invalid] = out_nodata

        a_profile.update(
            dtype="float32",
            count=1,
            nodata=out_nodata,
            compress="lzw",
        )

        with rasterio.open(out_path, "w", **a_profile) as dst:
            dst.write(out, 1)

    print("Done:", out_path)


if __name__ == "__main__":
    # ---- EDIT THESE ----
    A = r"Projected_K_step2.tif"
    B = r"2_John_K.tif"
    C = r"Projected_K_step3.tif"
    D = r"predictions_tas_K_combined_clip_v2.tif"
    OUT = r"Patrick_final_K.tif"

    main(A, B, C, D, OUT)
