#!/bin/bash
 
#PBS -P ge3
#PBS -q express
#PBS -l walltime=03:00:00,mem=192GB,ncpus=48,jobfs=100GB
#PBS -l storage=gdata/dg9+gdata/dz56+gdata/ge3+gdata/jl14
#PBS -l wd
#PBS -j oe


module avail gdal
module load gdal/3.0.2
module load openmpi/4.0.2
module load python3/3.7.4
source /home/547/zd6850/TestTIFVenv/scripts/nci_load_modules.sh

python3 mosaic_K.py