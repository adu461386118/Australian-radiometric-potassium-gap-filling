
from typing import List

import tensorflow as tf

from landshark.kerasmodel import (
    CatFeatInput,
    NumFeatInput,
    TargetData,
    get_feat_input_list,
    impute_embed_concat_layer,
)
from landshark.metadata import Training
from landshark.model import TrainingConfig
from tensorflow.keras import layers

def r2(y_true, y_pred):
    """Coefficient of determination metric."""
    SS_res = tf.reduce_sum(tf.math.squared_difference(y_true, y_pred))
    SS_tot = tf.reduce_sum(tf.math.squared_difference(y_true, tf.reduce_mean(y_true)))
    return 1 - SS_res / SS_tot

def TransformerBlock(embed_dim, num_heads):
    """Creates a transformer block as a Keras Model, not Sequential."""
    input_layer = layers.Input(shape=(None, embed_dim))
    attention_output = layers.MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim)(input_layer, input_layer, input_layer)
    attention_output = layers.LayerNormalization()(attention_output + input_layer)  # Add & Norm step
    output_layer = layers.Dense(embed_dim, activation="relu")(attention_output)
    return tf.keras.Model(inputs=input_layer, outputs=output_layer)


def model(
    num_feats: List[NumFeatInput],
    cat_feats: List[CatFeatInput],
    indices: tf.keras.Input,
    coords: tf.keras.Input,
    targets: List[TargetData],
    metadata: Training,
    params: TrainingConfig
) -> tf.keras.Model:
    """Example model config.
    Must match the signature above and return a compiled tf.keras.Model
    """

    l0 = impute_embed_concat_layer(num_feats, cat_feats, cat_embed_dims=3)
    # input size 3x3x3
    l1 = layers.Conv2D(64, (2, 2), activation='relu', padding='same')(l0)
    l1_padded = layers.ZeroPadding2D(padding=((0, 1), (0, 1)))(l1)
    l1a = layers.MaxPooling2D((2, 2))(l1_padded)
    l2 = layers.Conv2D(128, (2, 2), activation='relu', padding='same')(l1a)
    l2a = layers.MaxPooling2D((2, 2))(l2)

    # Bottleneck with Transformer
    l2b = layers.Conv2D(256, (2, 2), activation='relu', padding='same')(l2a)
    # Initialize your transformer block with the desired dimensions and number of heads
    transformer_block = TransformerBlock(256, 8)
    
    # Use the transformer block in your model
    l2b_flat = layers.Reshape((-1, 256))(l2b)  # Flatten for transformer: Output shape becomes (1, 256)
    l2b_trans = transformer_block(l2b_flat)  # Process through transformer: Output shape remains (1, 256)
    # Reshape to a spatial dimension that matches the transformer output
    l2b_reshaped = layers.Reshape((1, 1, 256))(l2b_trans)  # Reshape to the actual transformer output dimensions
    
    # Continue with upsampling
    u1 = layers.UpSampling2D((2, 2))(l2b_reshaped)

    l2_cropped = layers.Cropping2D(cropping=((0, 0), (0, 0)))(l2)  # Ensure dimensions match
    u1_concat = layers.Concatenate()([u1, l2_cropped])
    l2c = layers.Conv2D(128, (2, 2), activation='relu', padding='same')(u1_concat)
    u2 = layers.UpSampling2D((2, 2))(l2c)
    u2_concat = layers.Concatenate()([u2, l1_padded])
    l4 = layers.Conv2D(64, (2, 2), activation='relu', padding='same')(u2_concat)
    l5 = layers.Conv2D(16, (3, 3), activation='relu', padding='same')(l4)
    
    flat = tf.keras.layers.Flatten()(l5)
  
    
    ys = []
    losses = {}
    metrics = {}
    for i, t in enumerate(targets):
    
        #out = tf.keras.layers.Dense(40)(flat)
        #out = tf.keras.layers.Dropout(0.1)(out)
        #out = tf.keras.layers.Dense(20)(out)
        l_name = f"predictions_{t.label}"       
        out = tf.keras.layers.Dense(1, name=l_name)(flat)
        losses[l_name] = tf.keras.losses.MeanSquaredError(
            reduction=tf.keras.losses.Reduction.AUTO,
            # name='mean_squared_error'
        )
        ys.append(out)

    # Get some predictions for the labels
    # create keras model
    model_inputs = get_feat_input_list(num_feats, cat_feats)
    model = tf.keras.Model(inputs=model_inputs, outputs=ys)
    optimizer = tf.keras.optimizers.Adam()
    model.compile(loss=losses, optimizer=optimizer, metrics=[r2])
    model.summary()
    return model
