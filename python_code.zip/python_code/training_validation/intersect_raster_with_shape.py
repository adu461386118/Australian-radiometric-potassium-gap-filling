from os import path
from pathlib import Path
import numpy as np
import pandas as pd
import rasterio
import geopandas as gpd


def intersect_and_sample_shp(shp: Path, raster: Path):
    print("====================================\n", f"intersecting {shp.as_posix()}")
    pts = gpd.read_file(shp)
    for g in geom_cols:
        if g in pts.columns:
            pts = pts.drop(g, axis=1)
    coords = np.array([(p.x, p.y) for p in pts.geometry])
    geom = pd.DataFrame(coords, columns=geom_cols, index=pts.index)
    pts = pts.merge(geom, left_index=True, right_index=True)
    pts["raster_val"] = __extract_raster_points(raster, coords)
    return pts


def __extract_raster_points(raster: path, coords_deduped: np.ndarray):
    with rasterio.open(raster) as src:
        print(f"---- intersecting {raster}--------")
        return [x[0] for x in src.sample(coords_deduped)]


def intersect_sample_and_clean(shp: Path, raster: Path):
    df2 = intersect_and_sample_shp(shp, raster)
    # output_dir.mkdir(exist_ok=True, parents=True)
    #out_shp = output_dir.joinpath(shp.name)
    # df2.to_file(out_shp.parent.joinpath(out_shp.stem + '_intersected.shp'))
    print(shp.stem + '_' + raster.stem + '_intersected.csv')
    df2.to_csv(Path(".").joinpath(shp.stem + '_' + raster.stem + '_intersected.csv'))
    print("saved ")


if __name__ == '__main__':
    # local
    output_dir = Path('.')
    shapefile_location = Path("configs/data")
    geom_cols = ['POINT_X', 'POINT_Y']

    tifffile = Path("./predictions_cond_mean.tif")
    print("Add under the 'intersected_features:' section in yaml")
    print('='*100)
    shp = Path("/g/data/ge3/sudipta/jobs/uncoverml_models/wa_cond/1in10/gb/split/oos.shp")
    intersect_sample_and_clean(shp, tifffile)


# /g/data/ge3/sudipta/jobs/landshark_models/lake_eyre_cropped/04_11_2022/hw1_mean_318_5folds_complicated2/mean_318_std.tif
# /g/data/ge3/sudipta/jobs/landshark_models/lake_eyre_cropped/04_11_2022/hw1_mean_318_5folds_complicated2/mean_318.tif


