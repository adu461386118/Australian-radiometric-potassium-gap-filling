import os
import argparse
from osgeo import gdal, ogr
import numpy as np

# Set up argument parsing
parser = argparse.ArgumentParser(description='Calculate regression metrics between observed shapefile attributes and predicted raster values.')
parser.add_argument('-shp', '--shapefile', required=True, help='Path to the shapefile')
parser.add_argument('-tif', '--raster', required=True, help='Path to the raster (TIF) file')
parser.add_argument('-attribute', '--attribute', required=True, help='Attribute field name in the shapefile')

args = parser.parse_args()

# Open the shapefile
driver = ogr.GetDriverByName('ESRI Shapefile')
ds = driver.Open(args.shapefile, 0)  # Use the argument
layer = ds.GetLayer()

# Open the raster
raster = gdal.Open(args.raster)  # Use the argument
geotransform = raster.GetGeoTransform()
band = raster.GetRasterBand(1)

# Identify the NoData value for the raster band
nodata = band.GetNoDataValue()

observed = []
predicted = []

# Iterate over the shapefile's features
for feature in layer:
    geom = feature.GetGeometryRef()
    x, y = geom.GetX(), geom.GetY()  # Assuming point geometries

    true_value = feature.GetField(args.attribute)  # Use the argument

    # Calculate the corresponding row and column in the raster
    col = int((x - geotransform[0]) / geotransform[1])
    row = int((y - geotransform[3]) / geotransform[5])

    # Ensure the coordinates are within the raster boundary before reading
    if 0 <= col < raster.RasterXSize and 0 <= row < raster.RasterYSize:
        data = band.ReadAsArray(col, row, 1, 1)
        if data is not None and data.size > 0 and data[0, 0] != nodata:
            mean_val = np.mean(data)
            predicted.append(mean_val)
            observed.append(true_value)
    # If out of bounds or NoData, skip this feature
    else:
        continue

# Close the datasets
ds = None
raster = None

if observed and predicted:  # Ensure we have data to avoid division by zero
    observed = np.array(observed)
    predicted = np.array(predicted)
    mae = np.mean(np.abs(observed - predicted))
    mse = np.mean((observed - predicted) ** 2)
    rmse = np.sqrt(mse)
    r_squared = 1 - (np.sum((observed - predicted) ** 2) / np.sum((observed - np.mean(observed)) ** 2))

    print(f"MAE: {mae}")
    print(f"MSE: {mse}")
    print(f"RMSE: {rmse}")
    print(f"R-squared: {r_squared}")
else:
    print("No valid data points found.")
