#!/bin/bash
 
#PBS -l ncpus=48
#PBS -l mem=192GB
#PBS -l jobfs=10GB
#PBS -q normal
#PBS -P ge3
#PBS -l walltime=2:00:00
#PBS -l storage=gdata/dg9+gdata/dz56+gdata/ge3+gdata/jl14
#PBS -l wd
#PBS -j oe

module load intel-mkl/2021.4.0   python3/3.10.4   gdal/3.5.0   cuda/11.6.1  cudnn/8.2.2-cuda11.4  nccl/2.11.4 openmpi/4.1.2  tensorflow/2.8.0  parallel

source /g/data/ge3/sudipta/venvs/3p10land/bin/activate

bash merge.txt